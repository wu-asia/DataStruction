#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<algorithm>
#include<time.h>

typedef int ElemType;
const int MaxSize = 1000;
#define FINE 1
#define ERROR 0
typedef struct
{
	ElemType data[MaxSize];
	int last;
}SeqList;
//�˵�
void menu();
//˳����ĳ�ʼ��
void InitiList(SeqList* list);
//����Ԫ��
int InsElement(SeqList* list, ElemType e, int pos);
//ɾ��Ԫ��
int DelElement(SeqList* list, ElemType* e, int pos);
//����˳���
void VisitList(SeqList* list);
//˳�������
int ListLength(SeqList* list);
//����˳���
void ReverseList(SeqList* list);
//����
void SortList(SeqList* list);
int get_random_pos(int left, int right);
void Swap(ElemType* e1, ElemType* e2);
void quick_sort(ElemType arr[], int left, int right);
//�ϲ���������˳���
void MergeList(SeqList* list1, SeqList* list2);
//��������Ԫ��
int InsNElements(SeqList* list, int num, int pos, ElemType arr[], int sz);
//����ɾ��Ԫ��
int main()
{
	srand((unsigned int)time(NULL));
	SeqList l1;
	InitiList(&l1);
	SeqList l2 = { { 2, 3, 2, 1 }, 3 };
	l1 = { {1, 2, 3}, 2 };
	int input = 0;
	while (1)
	{
		menu();
		printf("������ѡ��:>");
		scanf("%d", &input);
		if (!input) break;
		switch (input)
		{
		case 0:
			printf("�˳�\n");
			break;
		case 1:
			printf("����l1�е�Ԫ�غ�λ��:>");
			ElemType elem1;
			int p1;
			std::cin >> elem1 >> p1;
			InsElement(&l1, elem1, p1);
			break;
		case 2:
			printf("����l2�е�Ԫ�غ�λ��:>");
			ElemType elem2;
			int p2;
			std::cin >> elem2 >> p2;
			InsElement(&l2, elem2, p2);
			break;
		case 3:
			printf("ɾ��l1��Ԫ�ص�λ��:>");
			int p_one;
			ElemType elem_one;
			std::cin >> p_one >> elem_one;
			DelElement(&l1, &elem_one, p_one);
			std::cout << "ɾ����Ԫ���ǣ�" << elem_one << std::endl;
			break;
		case 4:
			printf("ɾ��l2�е�Ԫ�ص�λ��:>");
			int p_two;
			ElemType elem_two;
			std::cin >> p_two >> elem_two;
			DelElement(&l2, &elem_two, p_two);
			std::cout << "ɾ����Ԫ���ǣ�" << elem_two << std::endl;
			break;
		case 5:
			printf("˳���l1�ĳ���Ϊ��%d\n", ListLength(&l1));
			break;
		case 6:
			printf("˳���l2�ĳ���Ϊ��%d\n", ListLength(&l2));
			break;
		case 7:
			ReverseList(&l1);
			break;
		case 8:
			ReverseList(&l2);
			break;
		case 9:
			SortList(&l1);
			break;
		case 10:
			SortList(&l2);
			break;
		case 11:
			MergeList(&l1, &l2);
			break;
		case 12:
			MergeList(&l2, &l1);
			break;
		case 13:
			VisitList(&l1);
			break;
		case 14:
			VisitList(&l2);
			break;
		}
	}
	
	VisitList(&l1);
	InsElement(&l1, 1000, 1);
	VisitList(&l1);
	printf("%d\n", ListLength(&l1));
	InsElement(&l1, 99, l1.last + 1);
	VisitList(&l1);
	SortList(&l1);
	VisitList(&l1);
	
	SortList(&l2);
	MergeList(&l1, &l2);
	VisitList(&l2);
	VisitList(&l1);
	return 0;
}
void menu()
{
	printf("0 �˳�\n");
	printf("1 ˳���l1�в���Ԫ��\n");
	printf("2 ˳���l2�в���Ԫ��\n");
	printf("3 ˳���l1��ɾ��Ԫ��\n");
	printf("4 ˳���l2��ɾ��Ԫ��\n");
	printf("5 �鿴˳���l1�ĳ���\n");
	printf("6 �鿴˳���l2�ĳ���\n");
	printf("7 ����˳���l1\n");
	printf("8 ����˳���l2\n");
	printf("9 ����˳���l1\n");
	printf("10 ����˳���l2\n");
	printf("11 �ϲ���������˳���(�ϲ���l1)\n");
	printf("12 �ϲ���������˳���(�ϲ���l2)\n");
	printf("13 ����˳���l1\n");
	printf("14 ����˳���l2\n");
}

void InitiList(SeqList* list)
{
	list->last = -1;
}

int InsElement(SeqList* list, ElemType e, int pos)
{
	if (pos < 0 || pos > list->last + 1 || list->last + 2 > MaxSize) return ERROR;
	for (int i = list->last; i >= pos; i--)
	{
		list->data[i + 1] = list->data[i];
	}
	list->data[pos] = e;
	list->last++;
	return FINE;
}

int DelElement(SeqList* list, ElemType* e, int pos)
{
	if (pos < 0 || pos > list->last) return ERROR;
	*e = list->data[pos];
	for (int i = pos + 1; i < list->last; i++)
	{
		list->data[i - 1] = list->data[i];
	}
	list->last--;
	return FINE;
}
void VisitList(SeqList* list)
{
	if (list->last == -1) printf("˳���Ϊ��\n");
	for (int i = 0; i <= list->last; i++)
	{
		std::cout << list->data[i] << " ";
	}
	std::cout << std::endl;
}

int ListLength(SeqList* list)
{
	return list->last + 1;
}

void ReverseList(SeqList* list)
{
	for (int i = 0, j = list->last; i < j; i++, j--)
	{
		ElemType tmp = list->data[i];
		list->data[i] = list->data[j];
		list->data[j] = tmp;
	}
}

void SortList(SeqList* list)
{
	quick_sort(list->data, 0, list->last);
}

int get_random_pos(int left, int right)
{
	return (rand() % (right - left + 1) + left);
}

void Swap(ElemType* e1, ElemType* e2)
{
	ElemType tmp = *e1;
	*e1 = *e2;
	*e2 = tmp;
}
void quick_sort(ElemType arr[], int left, int right)
{
	//�趨��������
	if (left >= right) return;
	int pos = get_random_pos(left, right);
	ElemType elem = arr[pos];
	//�ϲ�������������
	int cur = left, cur1 = left - 1, cur2 = right + 1;
	while (cur < cur2)
	{
		if (arr[cur] < elem) Swap(&arr[++cur1], &arr[cur++]);
		else if (arr[cur] == elem) cur++;
		else Swap(&arr[cur], &arr[--cur2]);
	}
	//[left, cur1], [cur1 + 1, cur2 - 1], [cur2, right]
	quick_sort(arr, left, cur1);
	quick_sort(arr, cur2, right);
}

void MergeList(SeqList* list1, SeqList* list2)
{
	int cur1 = list1->last;
	int cur2 = list2->last;
	int cur = cur1 + cur2 + 1;
	while (cur1 > 0 && cur2 > 0)
	{
		if (list1->data[cur1] >= list2->data[cur2])
			list1->data[cur--] = list1->data[cur1--];
		else
			list1->data[cur--] = list2->data[cur2--];
	}
	while (cur2 > 0)
		list1->data[cur--] = list2->data[cur2--];
	list1->last = list1->last + list2->last + 1;
}

int InsNElements(SeqList* list, int num, int pos, ElemType arr[], int sz)
{
	if (pos < 0 || pos > list->last + 1 || num + list->last + 1 > MaxSize) return ERROR;
	for (int i = list->last; i >= pos; i--)
	{
		list->data[i + pos] = list->data[i];
	}
	for (int i = pos; i < sz + pos; i++)
	{
		list->data[i] = arr[i];
	}
	list->last += num;
	return FINE;
}

int DelNElements(SeqList* list, int num, int pos)
{
	if (pos < 0 || pos > list->last || list->last + 1 - num < 0) return ERROR;
	for (int i = pos + 1; i <= list->last; i++)
	{
		list->data[i] = list->data[i + num];
	}
	list->last -= num;
	return ERROR;
}

void SortListWithEvenAndOdd(SeqList* list)
{
	int left = 0;
	int right = list->last;
	while (left < right)
	{
		ElemType* left_e = &list->data[left];
		ElemType* right_e = &list->data[right];
		if (*left_e % 2 == 0 && *right_e % 2 == 1)
		{
			Swap(left_e, right_e);
			left++;
			right--;
		}
		else if (*left_e % 2 == 0 && *right_e % 2 != 1)
			right--;
		else if (*left_e % 2 != 0 && *right_e % 2 == 1)
			left++;
		else
		{
			right--;
			left++;
		}
	}
}
