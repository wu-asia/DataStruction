﻿//#define StackSize 10010
//typedef int ElemType;
//#include"stack.h"
//#include"queue.h"
//void converse(int n, int base)
//{
//	SeqStack S;
//	InitStack(&S);
//	while (n)
//	{
//		Push(&S, n % base);
//		n /= base;
//	}
//	while (!IsStackEmpty(&S))
//	{
//		ElemType e;
//		Pop(&S, &e);
//		printf("%d", e);
//	}
//}
//int main()
//{
//	int n, base;
//	printf("请输入一个数字和要转换的进制：");
//	scanf("%d %d", &n, &base);
//	converse(n, base);
//	return 0;
//}